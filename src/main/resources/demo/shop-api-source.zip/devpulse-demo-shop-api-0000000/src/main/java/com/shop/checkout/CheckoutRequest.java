package com.shop.checkout;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

/** What the browser sends to check out a cart. */
public record CheckoutRequest(@Email String email, @Positive BigDecimal total, String note) {
}
