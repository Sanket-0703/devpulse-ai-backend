package com.shop.checkout;

import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/** Orders in the database. */
@Repository
public class OrderRepository {

    private static final String INSERT =
            "INSERT INTO orders (email, total) VALUES (?, ?) RETURNING id, email, total, created_at";

    private final JdbcTemplate jdbc;
    private final RowMapper<Order> mapper = (rs, row) ->
            new Order(rs.getLong("id"), rs.getString("email"), rs.getBigDecimal("total"), rs.getTimestamp("created_at").toInstant());

    public OrderRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Order create(CheckoutRequest request) {
        return jdbc.queryForObject(INSERT, mapper, request.email(), request.total());
    }

    public List<Order> findByEmail(String email) {
        return jdbc.query("SELECT * FROM orders WHERE email = ?", mapper, email);
    }
}
