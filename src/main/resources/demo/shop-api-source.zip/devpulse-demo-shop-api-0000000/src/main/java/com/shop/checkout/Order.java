package com.shop.checkout;

import java.math.BigDecimal;
import java.time.Instant;

/** A placed order. */
public record Order(Long id, String email, BigDecimal total, Instant createdAt) {
}
