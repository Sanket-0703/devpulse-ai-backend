package com.shop.payments;

import java.math.BigDecimal;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/** Charges cards through the payment provider's HTTP API. */
@Component
public class PaymentClient {

    private final RestClient http = RestClient.create("https://payments.example.com");

    /** Charges the customer; throws if the provider declines the card. */
    public void charge(String apiKey, BigDecimal amount) {
        http.post()
                .uri("/v1/charges")
                .header("Authorization", "Bearer " + apiKey)
                .body(new ChargeRequest(amount, "EUR"))
                .retrieve()
                .toBodilessEntity();
    }

    record ChargeRequest(BigDecimal amount, String currency) {
    }
}
