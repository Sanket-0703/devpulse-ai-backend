package com.shop.security;

import java.time.Clock;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Issues and validates opaque session tokens that expire after an hour. */
public class SessionTokens {

    private final Map<String, Instant> expiries = new ConcurrentHashMap<>();
    private final Clock clock;

    public SessionTokens(Clock clock) {
        this.clock = clock;
    }

    public String issue() {
        String token = java.util.UUID.randomUUID().toString();
        expiries.put(token, clock.instant().plusSeconds(3600));
        return token;
    }

    /** A token is valid if it was issued here and hasn't expired. */
    public boolean isValid(String token) {
        Instant expiry = expiries.get(token);
        return expiry != null && clock.instant().isBefore(expiry);
    }
}
