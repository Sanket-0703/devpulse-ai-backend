import { useState } from 'react'

import { checkout } from './api'

/** The cart page: total, a note for the order, and the checkout button. */
export function Cart({ email, total }: { email: string; total: number }) {
  const [note, setNote] = useState('')
  const [status, setStatus] = useState<'idle' | 'paying' | 'done'>('idle')

  async function pay() {
    setStatus('paying')
    await checkout(email, total, note)
    setStatus('done')
  }

  return (
    <section>
      <p>Total: {total.toFixed(2)}</p>
      <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note for the order" />
      <button onClick={pay} disabled={status === 'paying'}>
        Pay now
      </button>
    </section>
  )
}
