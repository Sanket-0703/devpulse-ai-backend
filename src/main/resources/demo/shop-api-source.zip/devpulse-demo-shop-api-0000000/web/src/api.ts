// Calls to the shop API from the browser.

export type Order = { id: number; email: string; total: number; createdAt: string }

export async function checkout(email: string, total: number, note: string): Promise<Order> {
  const response = await fetch('/api/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, total, note }),
  })
  if (!response.ok) throw new Error(`Checkout failed: ${response.status}`)
  return response.json()
}

export async function ordersFor(email: string): Promise<Order[]> {
  const response = await fetch(`/api/orders?email=${encodeURIComponent(email)}`)
  return response.json()
}
